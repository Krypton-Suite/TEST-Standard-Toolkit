#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Theme rendering helpers for the Windows theme collection.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>Reusable pixel-oriented control primitives for the Windows theme collection.
/// XP resource-derived themes can additionally use their extracted bitmap sprites.
/// </summary>
public static class WindowsThemeControlPainter
{
    public static void DrawCheckBox(Graphics graphics, Rectangle bounds, bool check, bool hot, bool pressed, Color face, Color border, Color accent)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) return;
        graphics.SmoothingMode = SmoothingMode.None;
        var box = new Rectangle(bounds.X, bounds.Y, Math.Min(bounds.Width, bounds.Height), Math.Min(bounds.Width, bounds.Height));
        using var fill = new SolidBrush(pressed ? ControlPaint.Dark(face) : face);
        using var pen = new Pen(hot ? accent : border);
        graphics.FillRectangle(fill, box);
        graphics.DrawRectangle(pen, box.X, box.Y, box.Width - 1, box.Height - 1);
        if (check)
        {
            using var mark = new Pen(accent, Math.Max(1, box.Width / 6)) { StartCap = LineCap.Square, EndCap = LineCap.Square };
            var p1 = new Point(box.X + box.Width / 5, box.Y + box.Height / 2);
            var p2 = new Point(box.X + box.Width * 2 / 5, box.Y + box.Height * 4 / 5);
            var p3 = new Point(box.X + box.Width * 4 / 5, box.Y + box.Height / 5);
            graphics.DrawLines(mark, new[] { p1, p2, p3 });
        }
    }

    public static void DrawRadioButton(Graphics graphics, Rectangle bounds, bool selected, bool hot, Color face, Color border, Color accent)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) return;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var d = Math.Min(bounds.Width, bounds.Height);
        var r = new Rectangle(bounds.X, bounds.Y, d - 1, d - 1);
        using var fill = new SolidBrush(face);
        using var pen = new Pen(hot ? accent : border);
        graphics.FillEllipse(fill, r); graphics.DrawEllipse(pen, r);
        if (selected)
        {
            int m = Math.Max(3, d / 3);
            using var dot = new SolidBrush(accent);
            graphics.FillEllipse(dot, new Rectangle(bounds.X + (d-m)/2, bounds.Y + (d-m)/2, m, m));
        }
    }

    public static void DrawProgressBar(Graphics graphics, Rectangle bounds, int value, int maximum, Color track, Color fill, Color border)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) return;
        maximum = Math.Max(1, maximum); value = Math.Clamp(value, 0, maximum);
        using var b = new SolidBrush(track); using var p = new Pen(border);
        graphics.FillRectangle(b, bounds); graphics.DrawRectangle(p, bounds.X, bounds.Y, bounds.Width-1, bounds.Height-1);
        int w = (int)Math.Round((bounds.Width - 2) * (double)value / maximum);
        if (w > 0) { using var f = new SolidBrush(fill); graphics.FillRectangle(f, bounds.X+1, bounds.Y+1, w, Math.Max(0,bounds.Height-2)); }
    }

    public static void DrawTab(Graphics graphics, Rectangle bounds, bool selected, Color face, Color selectedFace, Color border, Color text)
    {
        if (bounds.Width <= 0 || bounds.Height <= 0) return;
        var fill = selected ? selectedFace : face; using var b = new SolidBrush(fill); using var p = new Pen(border);
        graphics.FillRectangle(b,bounds); graphics.DrawRectangle(p,bounds.X,bounds.Y,bounds.Width-1,bounds.Height-1);
    }

    public static void DrawScrollTrack(Graphics graphics, Rectangle bounds, Color track, Color border)
    {
        using var b = new SolidBrush(track); using var p = new Pen(border);
        graphics.FillRectangle(b,bounds); if(bounds.Width>1&&bounds.Height>1) graphics.DrawRectangle(p,bounds.X,bounds.Y,bounds.Width-1,bounds.Height-1);
    }
}
