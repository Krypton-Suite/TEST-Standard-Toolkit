namespace Krypton.Toolkit;

public class RenderWindowsXPEmbedded : RenderWindowsXPLuna
{
    public override ToolStripRenderer RenderToolStrip([DisallowNull] PaletteBase? colorPalette)
    {
        if (colorPalette == null) ThrowHelper.ThrowArgumentNullException(nameof(colorPalette));
        return new KryptonWindowsXPEmbeddedRenderer(colorPalette.ColorTable);
    }
}
