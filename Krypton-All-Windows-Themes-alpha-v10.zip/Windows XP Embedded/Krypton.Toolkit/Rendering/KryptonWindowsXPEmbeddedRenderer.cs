namespace Krypton.Toolkit;

public sealed class KryptonWindowsXPEmbeddedRenderer : KryptonWindowsXPLunaRenderer
{
    public KryptonWindowsXPEmbeddedRenderer([DisallowNull] KryptonColorTable kct)
        : base(kct)
    {
    }
}
