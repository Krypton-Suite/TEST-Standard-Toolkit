#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>Loads extracted Windows XP theme sprites embedded as managed resources.</summary>
public static class WindowsXPThemeBitmapResources
{
    public static Bitmap? Load(System.Reflection.Assembly assembly, string fileName)
    {
        var resourceName = assembly.GetManifestResourceNames()
            .FirstOrDefault(name => name.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
        if (resourceName == null) return null;
        using var stream = assembly.GetManifestResourceStream(resourceName);
        return stream == null ? null : new Bitmap(stream);
    }

    /// <summary>Draws a vertically stacked Windows XP theme sprite state.</summary>
    public static void DrawSpriteSlice(Graphics graphics, Bitmap sprite, Rectangle destination, int state, int states)
    {
        if (sprite == null || destination.Width <= 0 || destination.Height <= 0 || states <= 0) return;
        int sourceHeight = Math.Max(1, sprite.Height / states);
        int index = Math.Clamp(state, 0, states - 1);
        var source = new Rectangle(0, index * sourceHeight, sprite.Width, sourceHeight);
        graphics.DrawImage(sprite, destination, source, GraphicsUnit.Pixel);
    }

    public static void DrawSpriteSlice(Graphics graphics, System.Reflection.Assembly assembly, string fileName, Rectangle destination, int state, int states)
    {
        using var sprite = Load(assembly, fileName);
        if (sprite != null) DrawSpriteSlice(graphics, sprite, destination, state, states);
    }
}
