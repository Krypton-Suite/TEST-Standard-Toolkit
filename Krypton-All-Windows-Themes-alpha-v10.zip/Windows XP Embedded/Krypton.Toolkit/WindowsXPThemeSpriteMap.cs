namespace Krypton.Toolkit
{
    internal static class WindowsXPThemeSpriteMap
    {
        public const string Button = "Button";
        public const string CheckBox = "Checkbox25";
        public const string RadioButton = "RadioButton25";
        public const string TabItem = "TabItemTop";
        public const string TabPaneEdge = "TabPaneEdge";
        public const string ProgressTrack = "ProgressTrack";
        public const string ProgressChunk = "ProgressChunk";
        public const string ScrollArrows = "ScrollArrows";
        public const string ScrollThumbHorizontal = "ScrollThumbHorizontal";
        public const string ScrollThumbVertical = "ScrollThumbVertical";
        public const string TrackBarHorizontal = "TrackBarHorizontal";
        public const string TrackBarVertical = "TrackBarVertical";
        public const string ListViewHeader = "ListViewHeader";
        public const string ToolBarBackground = "ToolBarBackground";
        public const string FrameCaptionMin = "FrameCaptionMin";
        public const string ResizeGrip = "ResizeGrip2";
    }
}
