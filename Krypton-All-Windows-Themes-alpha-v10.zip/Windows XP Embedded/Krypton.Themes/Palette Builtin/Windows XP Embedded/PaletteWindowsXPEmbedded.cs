namespace Krypton.Themes;

public sealed class PaletteWindowsXPEmbedded : PaletteWindowsXPLunaBase
{
    public PaletteWindowsXPEmbedded()
    {
        ThemeName = nameof(PaletteWindowsXPEmbedded);
    }

    public override IRenderer GetRenderer() => new Krypton.Toolkit.RenderWindowsXPEmbedded();
}
