# Windows XP Embedded — Krypton theme

This package now contains an extraction of the supplied `Embedded.msstyles` TEXTFILE resources.

## Extracted data

- `Resources/NormalDefault_INI.ini`
- `Resources/LargeFontsDefault_INI.ini`
- `Resources/ExtraLargeDefault_INI.ini`
- `Resources/THEMES_INI.ini`
- Exact RGB definitions from the theme INI resources in `EmbeddedColors.cs`
- Embedded bitmap resource payloads under `Resources/Bitmaps/`

The Embedded style is a Microsoft Windows XP visual style used by Windows Embedded Standard/POSReady. The `.msstyles` format stores theme properties in TEXTFILE resources and graphical resources separately.

The Krypton implementation uses the extracted values as its source palette. The bitmap payloads are retained as reference material for future renderer work.
