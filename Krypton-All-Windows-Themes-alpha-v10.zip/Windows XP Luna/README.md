# Windows XP Luna renderer and palettes for Krypton Standard Toolkit

This package contains a Windows XP Luna implementation based on the supplied `Luna.msstyles`.

## Source layout

Copy the files into the corresponding projects in the `alpha` branch:

```text
Source/Krypton Components/Krypton.Toolkit/Rendering/
    RenderWindowsXPLuna.cs
    KryptonWindowsXPLunaRenderer.cs

Source/Krypton Components/Krypton.Themes/Palette Builtin/Windows XP Luna/
    LunaColors.cs
    PaletteWindowsXPLunaBase.cs
    PaletteWindowsXPLunaBlue.cs
    PaletteWindowsXPLunaOlive.cs
    PaletteWindowsXPLunaSilver.cs
    KryptonWindowsXPLunaTheme.cs
```

The palette classes belong in `Krypton.Themes`; the renderer belongs in `Krypton.Toolkit`, matching the existing separation used by the Toolkit and Themes projects.

## Included Luna schemes

* `PaletteWindowsXPLunaBlue` — XP `NormalColor`
* `PaletteWindowsXPLunaOlive` — XP `HomeStead`
* `PaletteWindowsXPLunaSilver` — XP `Metallic`

`LunaColors.cs` contains the explicit RGB resource definitions extracted from the supplied style (348 Blue, 360 Olive, 364 Silver; 1,072 total).

## Renderer

`RenderWindowsXPLuna` is deliberately separate from the standard renderer. It provides:

* square XP-style control geometry;
* hard-edged, one-pixel bevels;
* vertical Luna button gradients;
* non-antialiased classic control edges;
* dedicated ToolStrip/MenuStrip button and menu highlighting through `KryptonWindowsXPLunaRenderer`.

The palette still uses Krypton's normal rendering pipeline for surfaces that do not need Luna-specific geometry. This keeps the implementation compatible with the existing renderer architecture while allowing the Luna-specific controls to be refined independently.

## Theme catalogue integration

The central theme catalogue is intentionally not modified by these files. To expose the schemes through `PaletteMode` and `KryptonExtendedThemeProvider`, add the three enum values and three `Extra(...)` descriptors in the same manner as the existing Retro themes.

Suggested names:

```text
PaletteMode.WindowsXPLunaBlue
PaletteMode.WindowsXPLunaOlive
PaletteMode.WindowsXPLunaSilver
```

Suggested family:

```text
KryptonThemeFamilies.WindowsXPLuna
```

and chrome kind:

```text
KryptonThemeChromeKind.Windows
```

The exact enum/family declarations should be added to the repository's central declarations rather than duplicated in this package.

## Direct use before catalogue integration

```csharp
var palette = new PaletteWindowsXPLunaBlue();
KryptonManager.CurrentGlobalPalette = palette;
```

or:

```csharp
KryptonManager.CurrentGlobalPalette = new PaletteWindowsXPLunaOlive();
KryptonManager.CurrentGlobalPalette = new PaletteWindowsXPLunaSilver();
```

## Notes

This is intended as a real Luna renderer, not merely an XP colour palette. Renderer geometry can be refined against XP screenshots or control captures without changing the extracted colour resource.
