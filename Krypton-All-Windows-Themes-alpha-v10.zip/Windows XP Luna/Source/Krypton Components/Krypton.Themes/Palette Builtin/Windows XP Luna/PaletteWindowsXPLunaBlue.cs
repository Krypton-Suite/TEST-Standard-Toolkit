#region BSD License
/* New BSD 3-Clause License. Modifications 2026. */
#endregion

namespace Krypton.Themes;

/// <summary>Windows XP Luna Blue (NormalColor) palette.</summary>
public sealed class PaletteWindowsXPLunaBlue : PaletteWindowsXPLunaBase
{
    public PaletteWindowsXPLunaBlue() => ThemeName = nameof(PaletteWindowsXPLunaBlue);
    protected override LunaPalette Luna => LunaColors.Blue;
}
