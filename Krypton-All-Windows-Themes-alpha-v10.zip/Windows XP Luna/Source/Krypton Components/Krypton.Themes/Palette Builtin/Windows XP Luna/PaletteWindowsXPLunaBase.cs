#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Modifications by Peter Wagner (aka Wagnerp), Simon Coghlan (aka Smurf-IV), tobitege et al. 2026 - 2026. All rights reserved.
 */
#endregion

namespace Krypton.Themes;

using Krypton.Toolkit;

/// <summary>
/// Base palette for the three Windows XP Luna visual styles.
/// </summary>
public abstract class PaletteWindowsXPLunaBase : PaletteProfessionalSystem
{
    /// <summary>Gets the extracted Windows XP Luna resource palette.</summary>
    protected abstract LunaPalette Luna { get; }

    /// <inheritdoc />
    public override IRenderer GetRenderer() => new RenderWindowsXPLuna();

    /// <inheritdoc />
    public override Color GetBackColor1(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        return style switch
        {
            PaletteBackStyle.Control or PaletteBackStyle.ControlClient or PaletteBackStyle.ControlAlternate
                or PaletteBackStyle.ControlCustom1 or PaletteBackStyle.ControlCustom2 or PaletteBackStyle.ControlCustom3
                => state == PaletteState.Disabled ? Luna.ControlDisabled : Luna.Control,

            PaletteBackStyle.PanelClient or PaletteBackStyle.PanelAlternate or PaletteBackStyle.PanelCustom1
                or PaletteBackStyle.PanelCustom2 or PaletteBackStyle.PanelCustom3
                => Luna.Control,

            PaletteBackStyle.InputControlStandalone or PaletteBackStyle.InputControlRibbon
                or PaletteBackStyle.InputControlCustom1 or PaletteBackStyle.InputControlCustom2
                or PaletteBackStyle.InputControlCustom3
                => state == PaletteState.Disabled ? Luna.ControlDisabled : Luna.EditFill,

            PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonGallery or PaletteBackStyle.ButtonAlternate
                or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonBreadCrumb or PaletteBackStyle.ButtonListItem
                or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonButtonSpec or PaletteBackStyle.ButtonCluster
                or PaletteBackStyle.ButtonNavigatorStack or PaletteBackStyle.ButtonNavigatorOverflow
                or PaletteBackStyle.ButtonNavigatorMini or PaletteBackStyle.ButtonForm or PaletteBackStyle.ButtonFormClose
                or PaletteBackStyle.ButtonCustom1 or PaletteBackStyle.ButtonCustom2 or PaletteBackStyle.ButtonCustom3
                or PaletteBackStyle.ButtonInputControl or PaletteBackStyle.ButtonCalendarDay
                => GetButtonBackColor(state),

            PaletteBackStyle.ContextMenuOuter or PaletteBackStyle.ContextMenuInner
                => Luna.Control,

            PaletteBackStyle.ContextMenuItemHighlight
                => state is PaletteState.Tracking or PaletteState.CheckedTracking ? Luna.ButtonTracking : SharedStaticVariables.EMPTY_COLOR,

            PaletteBackStyle.ContextMenuItemImageColumn => Luna.Control,

            PaletteBackStyle.FormMain or PaletteBackStyle.FormCustom1 or PaletteBackStyle.FormCustom2
                or PaletteBackStyle.FormCustom3 or PaletteBackStyle.HeaderForm
                => Luna.CaptionFill,

            PaletteBackStyle.HeaderPrimary or PaletteBackStyle.HeaderSecondary or PaletteBackStyle.HeaderCustom1
                or PaletteBackStyle.HeaderCustom2 or PaletteBackStyle.HeaderCustom3
                => Luna.Control,

            PaletteBackStyle.GridDataCellList or PaletteBackStyle.GridDataCellSheet
                or PaletteBackStyle.GridDataCellCustom1 or PaletteBackStyle.GridDataCellCustom2
                or PaletteBackStyle.GridDataCellCustom3
                => Luna.EditFill,

            PaletteBackStyle.GridHeaderColumnList or PaletteBackStyle.GridHeaderColumnSheet
                or PaletteBackStyle.GridHeaderColumnCustom1 or PaletteBackStyle.GridHeaderColumnCustom2
                or PaletteBackStyle.GridHeaderColumnCustom3 or PaletteBackStyle.GridHeaderRowList
                or PaletteBackStyle.GridHeaderRowSheet or PaletteBackStyle.GridHeaderRowCustom1
                or PaletteBackStyle.GridHeaderRowCustom2 or PaletteBackStyle.GridHeaderRowCustom3
                => Luna.Control,

            PaletteBackStyle.ControlToolTip => Luna.ToolTipFill,
            _ => base.GetBackColor1(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetBackColor2(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        return style switch
        {
            PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonGallery or PaletteBackStyle.ButtonAlternate
                or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonBreadCrumb or PaletteBackStyle.ButtonListItem
                or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonButtonSpec or PaletteBackStyle.ButtonCluster
                or PaletteBackStyle.ButtonNavigatorStack or PaletteBackStyle.ButtonNavigatorOverflow
                or PaletteBackStyle.ButtonNavigatorMini or PaletteBackStyle.ButtonForm or PaletteBackStyle.ButtonFormClose
                or PaletteBackStyle.ButtonCustom1 or PaletteBackStyle.ButtonCustom2 or PaletteBackStyle.ButtonCustom3
                or PaletteBackStyle.ButtonInputControl or PaletteBackStyle.ButtonCalendarDay
                => GetButtonBackColor2(state),
            PaletteBackStyle.FormMain or PaletteBackStyle.FormCustom1 or PaletteBackStyle.FormCustom2
                or PaletteBackStyle.FormCustom3 or PaletteBackStyle.HeaderForm
                => Luna.CaptionFill,
            PaletteBackStyle.ControlToolTip => Luna.ToolTipFill,
            _ => base.GetBackColor2(style, state)
        };
    }

    /// <inheritdoc />
    public override PaletteColorStyle GetBackColorStyle(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideState(state))
        {
            return PaletteColorStyle.Inherit;
        }

        return style switch
        {
            PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonGallery or PaletteBackStyle.ButtonAlternate
                or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonBreadCrumb or PaletteBackStyle.ButtonListItem
                or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonButtonSpec or PaletteBackStyle.ButtonCluster
                or PaletteBackStyle.ButtonNavigatorStack or PaletteBackStyle.ButtonNavigatorOverflow
                or PaletteBackStyle.ButtonNavigatorMini or PaletteBackStyle.ButtonForm or PaletteBackStyle.ButtonFormClose
                or PaletteBackStyle.ButtonCustom1 or PaletteBackStyle.ButtonCustom2 or PaletteBackStyle.ButtonCustom3
                or PaletteBackStyle.ButtonInputControl or PaletteBackStyle.ButtonCalendarDay
                => PaletteColorStyle.Linear,
            PaletteBackStyle.ContextMenuItemHighlight or PaletteBackStyle.ControlToolTip
                => PaletteColorStyle.Solid,
            _ => base.GetBackColorStyle(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetBorderColor1(PaletteBorderStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        return style switch
        {
            PaletteBorderStyle.ButtonStandalone or PaletteBorderStyle.ButtonGallery or PaletteBorderStyle.ButtonAlternate
                or PaletteBorderStyle.ButtonLowProfile or PaletteBorderStyle.ButtonBreadCrumb or PaletteBorderStyle.ButtonListItem
                or PaletteBorderStyle.ButtonCommand or PaletteBorderStyle.ButtonButtonSpec or PaletteBorderStyle.ButtonCluster
                or PaletteBorderStyle.ButtonNavigatorStack or PaletteBorderStyle.ButtonNavigatorOverflow
                or PaletteBorderStyle.ButtonNavigatorMini or PaletteBorderStyle.ButtonForm or PaletteBorderStyle.ButtonFormClose
                or PaletteBorderStyle.ButtonCustom1 or PaletteBorderStyle.ButtonCustom2 or PaletteBorderStyle.ButtonCustom3
                or PaletteBorderStyle.ButtonInputControl or PaletteBorderStyle.ButtonCalendarDay
                => state == PaletteState.Disabled ? Luna.DisabledText : Luna.ButtonBorder,

            PaletteBorderStyle.InputControlStandalone or PaletteBorderStyle.InputControlRibbon
                or PaletteBorderStyle.InputControlCustom1 or PaletteBorderStyle.InputControlCustom2
                or PaletteBorderStyle.InputControlCustom3
                => state == PaletteState.Disabled ? Luna.DisabledText : Luna.ControlBorder,

            PaletteBorderStyle.ControlClient or PaletteBorderStyle.ControlAlternate or PaletteBorderStyle.ControlGroupBox
                or PaletteBorderStyle.ControlCustom1 or PaletteBorderStyle.ControlCustom2 or PaletteBorderStyle.ControlCustom3
                or PaletteBorderStyle.ContextMenuOuter or PaletteBorderStyle.ContextMenuInner
                or PaletteBorderStyle.ContextMenuHeading or PaletteBorderStyle.ContextMenuSeparator
                or PaletteBorderStyle.ContextMenuItemSplit
                or PaletteBorderStyle.FormMain or PaletteBorderStyle.FormCustom1 or PaletteBorderStyle.FormCustom2
                or PaletteBorderStyle.FormCustom3 or PaletteBorderStyle.HeaderForm
                => Luna.EdgeShadow,
            _ => base.GetBorderColor1(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetBorderColor2(PaletteBorderStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        return style switch
        {
            PaletteBorderStyle.ButtonStandalone or PaletteBorderStyle.ButtonGallery or PaletteBorderStyle.ButtonAlternate
                or PaletteBorderStyle.ButtonLowProfile or PaletteBorderStyle.ButtonBreadCrumb or PaletteBorderStyle.ButtonListItem
                or PaletteBorderStyle.ButtonCommand or PaletteBorderStyle.ButtonButtonSpec or PaletteBorderStyle.ButtonCluster
                or PaletteBorderStyle.ButtonNavigatorStack or PaletteBorderStyle.ButtonNavigatorOverflow
                or PaletteBorderStyle.ButtonNavigatorMini or PaletteBorderStyle.ButtonForm or PaletteBorderStyle.ButtonFormClose
                or PaletteBorderStyle.ButtonCustom1 or PaletteBorderStyle.ButtonCustom2 or PaletteBorderStyle.ButtonCustom3
                or PaletteBorderStyle.ButtonInputControl or PaletteBorderStyle.ButtonCalendarDay
                => state == PaletteState.Disabled ? Luna.DisabledText : Luna.EdgeHighlight,

            PaletteBorderStyle.InputControlStandalone or PaletteBorderStyle.InputControlRibbon
                or PaletteBorderStyle.InputControlCustom1 or PaletteBorderStyle.InputControlCustom2
                or PaletteBorderStyle.InputControlCustom3
                => state == PaletteState.Disabled ? Luna.DisabledText : Luna.EdgeHighlight,
            _ => base.GetBorderColor2(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetContentShortTextColor1(PaletteContentStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideState(state))
        {
            return base.GetContentShortTextColor1(style, state);
        }

        if (state == PaletteState.Disabled)
        {
            return Luna.DisabledText;
        }

        return style switch
        {
            PaletteContentStyle.HeaderPrimary or PaletteContentStyle.HeaderSecondary
                or PaletteContentStyle.HeaderCustom1 or PaletteContentStyle.HeaderCustom2
                or PaletteContentStyle.HeaderCustom3 or PaletteContentStyle.HeaderForm
                => Luna.CaptionText,
            PaletteContentStyle.LabelToolTip or PaletteContentStyle.LabelSuperTip or PaletteContentStyle.LabelKeyTip
                => Luna.ToolTipText,
            _ => Luna.Text
        };
    }

    /// <inheritdoc />
    public override Color GetContentShortTextColor2(PaletteContentStyle style, PaletteState state) =>
        GetContentShortTextColor1(style, state);

    private Color GetButtonBackColor(PaletteState state) => state switch
    {
        PaletteState.Disabled => Luna.ControlDisabled,
        PaletteState.Tracking or PaletteState.CheckedTracking => Luna.ButtonTracking,
        PaletteState.Pressed or PaletteState.CheckedPressed => Luna.ButtonPressed,
        PaletteState.CheckedNormal => Luna.ButtonChecked,
        _ => Luna.ButtonFace
    };

    private Color GetButtonBackColor2(PaletteState state) => state switch
    {
        PaletteState.Disabled => Luna.ControlDisabled,
        PaletteState.Tracking or PaletteState.CheckedTracking => Luna.ButtonTracking2,
        PaletteState.Pressed or PaletteState.CheckedPressed => Luna.ButtonPressed2,
        PaletteState.CheckedNormal => Luna.ButtonChecked2,
        _ => Luna.ButtonFace2
    };
}
