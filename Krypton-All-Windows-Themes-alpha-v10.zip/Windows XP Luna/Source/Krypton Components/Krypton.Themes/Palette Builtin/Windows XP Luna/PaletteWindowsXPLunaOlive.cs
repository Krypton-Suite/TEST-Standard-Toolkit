#region BSD License
/* New BSD 3-Clause License. Modifications 2026. */
#endregion

namespace Krypton.Themes;

/// <summary>Windows XP Luna Olive Green (HomeStead) palette.</summary>
public sealed class PaletteWindowsXPLunaOlive : PaletteWindowsXPLunaBase
{
    public PaletteWindowsXPLunaOlive() => ThemeName = nameof(PaletteWindowsXPLunaOlive);
    protected override LunaPalette Luna => LunaColors.Olive;
}
