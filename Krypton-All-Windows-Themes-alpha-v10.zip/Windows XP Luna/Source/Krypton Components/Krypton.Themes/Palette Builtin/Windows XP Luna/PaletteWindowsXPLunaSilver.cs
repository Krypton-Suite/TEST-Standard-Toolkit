#region BSD License
/* New BSD 3-Clause License. Modifications 2026. */
#endregion

namespace Krypton.Themes;

/// <summary>Windows XP Luna Silver (Metallic) palette.</summary>
public sealed class PaletteWindowsXPLunaSilver : PaletteWindowsXPLunaBase
{
    public PaletteWindowsXPLunaSilver() => ThemeName = nameof(PaletteWindowsXPLunaSilver);
    protected override LunaPalette Luna => LunaColors.Silver;
}
