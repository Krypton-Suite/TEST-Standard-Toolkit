#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Modifications by Peter Wagner (aka Wagnerp), Simon Coghlan (aka Smurf-IV), tobitege et al. 2026 - 2026. All rights reserved.
 */
#endregion

namespace Krypton.Themes;

/// <summary>
/// Convenience factory for the Windows XP Luna palettes.
/// </summary>
public static class KryptonWindowsXPLunaTheme
{
    public static PaletteWindowsXPLunaBlue Blue => new();
    public static PaletteWindowsXPLunaOlive Olive => new();
    public static PaletteWindowsXPLunaSilver Silver => new();
}
