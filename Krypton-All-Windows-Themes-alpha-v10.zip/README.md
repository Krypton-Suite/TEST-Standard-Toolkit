# Krypton Windows Theme Collection — alpha v4

Themes included:

- Windows XP Luna — Blue, Olive, Silver
- Windows XP Royale — Energy Blue
- Windows XP Embedded
- Windows 10 Acrylic — Light, Dark
- Windows 11 Mica — Light, Dark, Mica Alt Light, Mica Alt Dark

XP themes use the extracted `.msstyles` bitmap resources through a shared
sprite-rendering infrastructure. Acrylic and Mica retain the Windows/DWM
material model and use vector control primitives over the real system material.

This is source-level alpha integration work and should be reviewed against the
current Standard-Toolkit alpha source before merging.
