# Windows Themes alpha v10 — validation report

## Changes made

- Added the supplied `Krypton.Resources` project containing the Windows XP `.resx` resource sets.
- Removed the nonexistent `WindowsThemeControlPainter` dependency from `WindowsModernControlPainter`.
- Replaced `OperatingSystem.IsWindows*` calls in the Windows 10 Acrylic helper with `RuntimeInformation.IsOSPlatform`, which is compatible with the legacy target frameworks being used by the theme work.
- Removed `sealed` from XP renderer base classes that already have derived renderers.
- Added `WindowsXPThemeResourceBridge` showing the intended typed-resource access path for Luna, Embedded, Royale and Zune.

## Important validation status

This archive is source-preparation work, not a claimed successful build. The supplied theme bundle does not contain the complete current Standard Toolkit solution/project files for `Krypton.Toolkit` and `Krypton.Themes`, so a full multi-target build cannot be performed from this archive alone.

The next validation must therefore be performed in the user's `TEST-Standard-Toolkit` checkout using the repository's actual solution and project references.

## Expected validation order

1. Add/reference `Krypton.Resources` in the actual solution.
2. Build `Krypton.Resources`.
3. Reference `Krypton.Resources` from `Krypton.Toolkit` and/or `Krypton.Themes` as appropriate for the existing architecture.
4. Build `Krypton.Toolkit` for net472, net48, net481, net8.0-windows, net9.0-windows and net10.0-windows.
5. Build `Krypton.Themes`.
6. Resolve the actual `KryptonExtendedThemeProvider` family/chrome registrations against the definitions present in the checkout.
7. Run TestForm and visually inspect the Windows XP, Windows 10 Acrylic and Windows 11 Mica themes.
