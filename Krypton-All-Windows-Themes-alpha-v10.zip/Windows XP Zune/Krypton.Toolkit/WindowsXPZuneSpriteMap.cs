namespace Krypton.Toolkit
{
    internal static class WindowsXPZuneSpriteMap
    {
        public const string Button = "Button";
        public const string CheckBox = "Checkbox25";
        public const string RadioButton = "RadioButton25";
        public const string TabItem = "TabItemTop";
        public const string ProgressTrack = "ProgressTrack";
        public const string ProgressChunk = "ProgressChunk";
        public const string ScrollArrows = "ScrollArrows";
        public const string ScrollThumbHorizontal = "ScrollThumbHorizontal";
        public const string ScrollThumbVertical = "ScrollThumbVertical";
        public const string ListViewHeader = "ListViewHeader";
        public const string ToolBarBackground = "ToolBarBackground";
        public const string ResizeGrip = "ResizeGrip2";
    }
}
