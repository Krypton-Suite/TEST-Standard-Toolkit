using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Krypton.Toolkit
{
    internal static class WindowsXPZuneSpriteRenderer
    {
        public static Bitmap? Load(Assembly assembly, string bitmapName)
        {
            string fileName = bitmapName.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase)
                ? bitmapName : bitmapName + ".bmp";
            string? name = assembly.GetManifestResourceNames()
                .FirstOrDefault(n => n.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
            if (name is null) return null;
            using Stream? stream = assembly.GetManifestResourceStream(name);
            if (stream is null) return null;
            using Bitmap source = new(stream);
            return new Bitmap(source);
        }

        public static bool Draw(Graphics graphics, Rectangle destination,
            Assembly assembly, string bitmapName, Rectangle? source = null)
        {
            using Bitmap? bitmap = Load(assembly, bitmapName);
            if (bitmap is null) return false;
            Rectangle sourceRect = source ?? new Rectangle(Point.Empty, bitmap.Size);
            var interpolation = graphics.InterpolationMode;
            var pixelOffset = graphics.PixelOffsetMode;
            graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
            graphics.PixelOffsetMode = PixelOffsetMode.Half;
            graphics.DrawImage(bitmap, destination, sourceRect, GraphicsUnit.Pixel);
            graphics.InterpolationMode = interpolation;
            graphics.PixelOffsetMode = pixelOffset;
            return true;
        }
    }
}
