namespace Krypton.Toolkit
{
    public class RenderWindowsXPZune : RenderWindowsXPRoyaleNoir
    {
    }

    public class KryptonWindowsXPZuneRenderer : KryptonWindowsXPRoyaleNoirRenderer
    {
    }
}
