# Windows XP Zune — Krypton alpha

Dedicated Krypton source package derived from the supplied `zune.msstyles`.

Zune was an officially released Microsoft Windows XP visual style associated
with the Zune media player. It resembles Royale/Royale Noir, with brown/light
shading and an orange Start button. citeturn0search12turn0search0

The package adds a dedicated Zune renderer/palette and the XP resource-backed
sprite infrastructure. The original `.msstyles` binary is not redistributed.

This is source-level alpha work and should be checked against the current
Standard-Toolkit alpha checkout before merging.
