using System.Drawing;

namespace Krypton.Themes
{
    internal static class WindowsXPZuneColors
    {
        public static readonly Color Accent = Color.FromArgb(230, 126, 34);
        public static readonly Color AccentDark = Color.FromArgb(116, 68, 38);
        public static readonly Color Surface = Color.FromArgb(238, 230, 218);
        public static readonly Color SurfaceDark = Color.FromArgb(64, 52, 45);
        public static readonly Color Text = Color.FromArgb(35, 31, 28);
    }
}
