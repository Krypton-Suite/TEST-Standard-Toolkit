using Krypton.Toolkit;

namespace Krypton.Themes
{
    public class PaletteWindowsXPZune : PaletteWindowsXPRoyaleNoir
    {
        public PaletteWindowsXPZune()
        {
            ThemeName = "Windows XP Zune";
        }

        public override RendererBase GetRenderer() => new RenderWindowsXPZune();
    }
}
