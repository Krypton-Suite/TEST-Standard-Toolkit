# Windows XP Royale Noir — Krypton alpha

Created from the supplied `Royale Noir(1).msstyles`.

- PE resource extraction completed.
- 7 TEXTFILE resources extracted.
- 372 bitmap resources extracted.
- 133 colour definitions extracted from `NORMALDARKROYALE_INI`.
- Dedicated Royale Noir palette and renderer added.

Royale Noir was an unreleased/incomplete Microsoft visual style with a
blackish blue/purple appearance and known visual inconsistencies. The source
theme's characteristics are intentionally preserved.
