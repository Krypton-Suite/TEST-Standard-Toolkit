using System.Drawing;
using Krypton.Toolkit;

namespace Krypton.Toolkit
{
    /// <summary>
    /// Dedicated renderer for the Windows XP Royale Noir visual style.
    /// </summary>
    public class RenderWindowsXPRoyaleNoir : RenderWindowsXPRoyale
    {
        public override Color GetControlBackColor() => Krypton.Themes.RoyaleNoirColors.Get("Control");
        public override Color GetControlBorderColor() => Krypton.Themes.RoyaleNoirColors.BorderColor;
        public override Color GetControlTextColor() => Krypton.Themes.RoyaleNoirColors.TextColor;
    }
}
