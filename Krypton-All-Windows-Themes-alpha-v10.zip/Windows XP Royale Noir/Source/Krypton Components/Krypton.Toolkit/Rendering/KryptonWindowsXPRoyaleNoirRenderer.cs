using System.Drawing;

namespace Krypton.Toolkit
{
    /// <summary>
    /// Royale Noir ToolStrip renderer, based on the dedicated Royale renderer.
    /// </summary>
    public class KryptonWindowsXPRoyaleNoirRenderer : KryptonWindowsXPRoyaleRenderer
    {
        protected override Color MenuBackColor => Krypton.Themes.RoyaleNoirColors.Background;
        protected override Color MenuHighlightColor => Krypton.Themes.RoyaleNoirColors.Highlight;
    }
}
