# Windows XP Royale Noir

Resource-derived Krypton theme based on the supplied `Royale Noir(1).msstyles`.

The file contains both the normal Royale and dark Royale resource sets; this
package uses the `NORMALDARKROYALE_INI` colour definitions for the Noir palette
and extracts all RT_BITMAP resources for renderer integration.

Royale Noir was an unreleased/incomplete Microsoft visual style, so this
implementation preserves the source theme's actual resources rather than
silently correcting its original visual quirks.
