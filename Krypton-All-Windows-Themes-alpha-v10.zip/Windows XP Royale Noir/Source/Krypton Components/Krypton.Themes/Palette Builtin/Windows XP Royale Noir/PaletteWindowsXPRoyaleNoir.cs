using Krypton.Toolkit;

namespace Krypton.Themes
{
    /// <summary>
    /// Windows XP Royale Noir palette derived from the supplied Royale Noir
    /// .msstyles resources.
    /// </summary>
    public sealed class PaletteWindowsXPRoyaleNoir : PaletteWindowsXPRoyaleBase
    {
        public override string ThemeName => "Windows XP Royale Noir";

        public override RenderBase GetRenderer() => new RenderWindowsXPRoyaleNoir();
    }
}
