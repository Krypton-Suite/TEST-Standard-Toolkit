#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// Bridges Windows XP theme renderers to the strongly typed resources in Krypton.Resources.
/// </summary>
internal static class WindowsXPThemeResourceBridge
{
    internal static Bitmap? LunaButton => ResourceFiles.WindowsXPLuna.WindowsXPLunaImageResources.Button;
    internal static Bitmap? EmbeddedButton => ResourceFiles.WindowsXPEmbedded.WindowsXPEmbeddedImageResources.Button;
    internal static Bitmap? RoyaleButton => ResourceFiles.WindowsXPRoyale.WindowsXPRoyaleImageResources.Button;
    internal static Bitmap? ZuneButton => ResourceFiles.WindowsXPZune.WindowsXPZuneImageResources.Button;

    internal static void DrawButton(Graphics graphics, Bitmap? sprite, Rectangle bounds, int state)
    {
        if (graphics == null || sprite == null || bounds.Width <= 0 || bounds.Height <= 0) return;

        int states = 5;
        int sourceHeight = Math.Max(1, sprite.Height / states);
        int index = Math.Clamp(state, 0, states - 1);
        var source = new Rectangle(0, index * sourceHeight, sprite.Width, sourceHeight);
        graphics.DrawImage(sprite, bounds, source, GraphicsUnit.Pixel);
    }
}
