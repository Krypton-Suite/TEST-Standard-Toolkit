#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Modifications by Peter Wagner (aka Wagnerp), 2026. All rights reserved.
 */
#endregion

namespace Krypton.Themes;

using Krypton.Toolkit;

/// <summary>
/// Windows XP Royale (Energy Blue) palette extracted from Royale.msstyles.
/// </summary>
public sealed class PaletteWindowsXPRoyale : PaletteWindowsXPRoyaleBase
{
    protected override RoyalePalette Royale => RoyaleColors.EnergyBlue;

    public override string ThemeName => "Windows XP Royale (Energy Blue)";
}
