# Windows XP Royale (Energy Blue)

This package was generated from the supplied `Royale.msstyles`.

The colour definitions are extracted from the `NORMALROYALE_INI` TEXTFILE
resource in the Microsoft visual style. The implementation provides a
dedicated Krypton renderer and palette rather than inheriting the Luna theme.

Royale was the Energy Blue / Media Center visual style introduced with
Windows XP Media Center Edition 2005. It is known for its vivid blue and
green glossy/faux-reflective appearance.

Central `PaletteMode` / `KryptonExtendedThemeProvider` registration is
intentionally not included; integrate it against the current alpha source.
