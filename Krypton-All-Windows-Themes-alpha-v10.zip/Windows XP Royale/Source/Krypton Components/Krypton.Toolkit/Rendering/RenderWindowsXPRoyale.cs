#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Modifications by Peter Wagner (aka Wagnerp), Simon Coghlan (aka Smurf-IV), tobitege et al. 2026 - 2026. All rights reserved.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// Windows XP Royale renderer. Adds the hard-edged, one-pixel bevel treatment used
/// by Luna while leaving Krypton's normal renderer responsible for controls that
/// do not need Luna-specific geometry.
/// </summary>
public class RenderWindowsXPRoyale : RenderStandard
{
    /// <inheritdoc />
    public override ToolStripRenderer RenderToolStrip([DisallowNull] PaletteBase? colorPalette)
    {
        if (colorPalette == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(colorPalette));
        }

        return new KryptonWindowsXPRoyaleRenderer(colorPalette.ColorTable);
    }

    /// <inheritdoc />
    public override GraphicsPath GetBackPath([DisallowNull] RenderContext context,
        Rectangle rect,
        [DisallowNull] IPaletteBorder palette,
        VisualOrientation orientation,
        PaletteState state)
    {
        // XP Royale has square control corners. Do not allow a modern rounded path
        // to leak into the classic renderer when a control requests a border.
        if (rect.Width <= 0 || rect.Height <= 0 ||
            palette.GetBorderDraw(state) != InheritBool.True ||
            !CommonHelper.HasABorder(palette.GetBorderDrawBorders(state)) ||
            palette.GetBorderWidth(state) <= 0)
        {
            var path = new GraphicsPath();
            path.AddRectangle(rect);
            return path;
        }

        return base.GetBackPath(context, rect, palette, orientation, state);
    }

    /// <inheritdoc />
    public override IDisposable? DrawBack(RenderContext context,
        Rectangle rect,
        GraphicsPath path,
        IPaletteBack palette,
        VisualOrientation orientation,
        PaletteState state,
        IDisposable? memento)
    {
        if (context == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(context));
        }
        if (path == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(path));
        }
        if (palette == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(palette));
        }

        if (rect.Width <= 0 || rect.Height <= 0 ||
            CommonHelper.IsOverrideState(state) ||
            palette.GetBackColorStyle(state) != PaletteColorStyle.Linear)
        {
            return base.DrawBack(context, rect, path, palette, orientation, state, memento);
        }

        var top = palette.GetBackColor1(state);
        var bottom = palette.GetBackColor2(state);
        if (top == Color.Empty || bottom == Color.Empty)
        {
            return base.DrawBack(context, rect, path, palette, orientation, state, memento);
        }

        var graphics = context.Graphics;
        var oldSmoothing = graphics.SmoothingMode;
        var oldPixel = graphics.PixelOffsetMode;
        var oldClip = graphics.Clip;

        graphics.SmoothingMode = SmoothingMode.None;
        graphics.PixelOffsetMode = PixelOffsetMode.None;

        try
        {
            graphics.SetClip(path, CombineMode.Intersect);

            using var brush = new LinearGradientBrush(rect, top, bottom, 90f);
            graphics.FillRectangle(brush, rect);

            // Royale's classic controls use a very thin light/dark bevel. Keep it
            // deliberately square and avoid anti-aliased geometry.
            if (rect.Width > 1 && rect.Height > 1)
            {
                using var lightPen = new Pen(RoyaleRenderHelper.Lighten(top, 0.28f));
                using var darkPen = new Pen(RoyaleRenderHelper.Darken(bottom, 0.30f));

                int right = rect.Right - 1;
                int bottomEdge = rect.Bottom - 1;

                graphics.DrawLine(lightPen, rect.Left, rect.Top, right, rect.Top);
                graphics.DrawLine(lightPen, rect.Left, rect.Top, rect.Left, bottomEdge);
                graphics.DrawLine(darkPen, right, rect.Top, right, bottomEdge);
                graphics.DrawLine(darkPen, rect.Left, bottomEdge, right, bottomEdge);
            }
        }
        finally
        {
            graphics.Clip = oldClip;
            graphics.SmoothingMode = oldSmoothing;
            graphics.PixelOffsetMode = oldPixel;
        }

        return memento;
    }

    /// <inheritdoc />
    public override void DrawBorder(RenderContext context,
        Rectangle rect,
        IPaletteBorder palette,
        VisualOrientation orientation,
        PaletteState state)
    {
        if (palette == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(palette));
        }

        if (rect.Width <= 0 || rect.Height <= 0 ||
            palette.GetBorderWidth(state) <= 0 ||
            palette.GetBorderDraw(state) != InheritBool.True ||
            !CommonHelper.HasABorder(palette.GetBorderDrawBorders(state)))
        {
            return;
        }

        // Let the base renderer handle complex/non-square border combinations;
        // Luna's back renderer supplies the one-pixel bevel for the common case.
        base.DrawBorder(context, rect, palette, orientation, state);
    }
}

internal static class RoyaleRenderHelper
{
    internal static Color Lighten(Color color, float amount)
    {
        amount = Math.Clamp(amount, 0f, 1f);
        return Color.FromArgb(color.A,
            color.R + (int)((255 - color.R) * amount),
            color.G + (int)((255 - color.G) * amount),
            color.B + (int)((255 - color.B) * amount));
    }

    internal static Color Darken(Color color, float amount)
    {
        amount = Math.Clamp(amount, 0f, 1f);
        return Color.FromArgb(color.A,
            (int)(color.R * (1f - amount)),
            (int)(color.G * (1f - amount)),
            (int)(color.B * (1f - amount)));
    }
}
