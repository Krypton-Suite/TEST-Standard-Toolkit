#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Modifications by Peter Wagner (aka Wagnerp), Simon Coghlan (aka Smurf-IV), tobitege et al. 2026 - 2026. All rights reserved.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// ToolStrip/MenuStrip renderer for Windows XP Royale.
/// </summary>
public sealed class KryptonWindowsXPRoyaleRenderer : KryptonProfessionalRenderer
{
    public KryptonWindowsXPRoyaleRenderer([DisallowNull] KryptonColorTable kct)
        : base(kct)
    {
    }

    protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
    {
        using var brush = new SolidBrush(KCT.ToolStripGradientBegin);
        e.Graphics.FillRectangle(brush, new Rectangle(Point.Empty, e.ToolStrip.Size));
    }

    protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
    {
        if (e.Item is ToolStripMenuItem { Selected: true })
        {
            var bounds = new Rectangle(Point.Empty, e.Item.Size);
            using var brush = new SolidBrush(KCT.MenuItemSelected);
            using var pen = new Pen(KCT.MenuItemBorder);

            e.Graphics.FillRectangle(brush, bounds);
            if (bounds.Width > 1 && bounds.Height > 1)
            {
                e.Graphics.DrawRectangle(pen, 0, 0, bounds.Width - 1, bounds.Height - 1);
            }
            return;
        }

        base.OnRenderMenuItemBackground(e);
    }

    protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
    {
        if (e.Item is ToolStripButton button && e.Item.Width > 0 && e.Item.Height > 0)
        {
            int state = button.Enabled ? (button.Pressed ? 2 : button.Selected ? 1 : button.Checked ? 3 : 0) : 4;
            var assembly = typeof(WindowsXPThemeBitmapResources).Assembly;
            using var sprite = WindowsXPThemeBitmapResources.Load(assembly, "Button.bmp");
            if (sprite != null)
            {
                WindowsXPThemeBitmapResources.DrawSpriteSlice(e.Graphics, sprite, new Rectangle(Point.Empty, e.Item.Size), state, 5);
                return;
            }
        }

        base.OnRenderButtonBackground(e);
    }
}
