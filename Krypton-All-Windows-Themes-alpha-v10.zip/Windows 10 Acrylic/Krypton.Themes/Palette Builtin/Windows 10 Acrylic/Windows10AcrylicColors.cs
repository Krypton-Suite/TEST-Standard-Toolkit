namespace Krypton.Themes;

internal static class Windows10AcrylicColors
{
    internal static readonly Color LightBackground = Color.FromArgb(243, 243, 243);
    internal static readonly Color LightSurface = Color.FromArgb(250, 250, 250);
    internal static readonly Color LightSurfaceSecondary = Color.FromArgb(245, 245, 245);
    internal static readonly Color LightBorder = Color.FromArgb(210, 210, 210);
    internal static readonly Color LightText = Color.FromArgb(32, 32, 32);
    internal static readonly Color LightDisabledText = Color.FromArgb(160, 160, 160);
    internal static readonly Color LightHover = Color.FromArgb(229, 229, 229);
    internal static readonly Color LightPressed = Color.FromArgb(215, 215, 215);
    internal static readonly Color LightSelection = Color.FromArgb(204, 228, 255);

    internal static readonly Color DarkBackground = Color.FromArgb(32, 32, 32);
    internal static readonly Color DarkSurface = Color.FromArgb(43, 43, 43);
    internal static readonly Color DarkSurfaceSecondary = Color.FromArgb(38, 38, 38);
    internal static readonly Color DarkBorder = Color.FromArgb(75, 75, 75);
    internal static readonly Color DarkText = Color.FromArgb(243, 243, 243);
    internal static readonly Color DarkDisabledText = Color.FromArgb(110, 110, 110);
    internal static readonly Color DarkHover = Color.FromArgb(55, 55, 55);
    internal static readonly Color DarkPressed = Color.FromArgb(65, 65, 65);
    internal static readonly Color DarkSelection = Color.FromArgb(51, 103, 153);
}
