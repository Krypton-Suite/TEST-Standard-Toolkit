namespace Krypton.Themes;

using Krypton.Toolkit;

public abstract class PaletteWindows10AcrylicBase : PaletteProfessionalSystem
{
    protected abstract bool IsDark { get; }

    public override IRenderer GetRenderer() => new RenderWindows10Acrylic();

    protected Color Background => IsDark ? Windows10AcrylicColors.DarkBackground : Windows10AcrylicColors.LightBackground;
    protected Color Surface => IsDark ? Windows10AcrylicColors.DarkSurface : Windows10AcrylicColors.LightSurface;
    protected Color SurfaceSecondary => IsDark ? Windows10AcrylicColors.DarkSurfaceSecondary : Windows10AcrylicColors.LightSurfaceSecondary;
    protected Color Border => IsDark ? Windows10AcrylicColors.DarkBorder : Windows10AcrylicColors.LightBorder;
    protected Color Text => IsDark ? Windows10AcrylicColors.DarkText : Windows10AcrylicColors.LightText;
    protected Color DisabledText => IsDark ? Windows10AcrylicColors.DarkDisabledText : Windows10AcrylicColors.LightDisabledText;
    protected Color Hover => IsDark ? Windows10AcrylicColors.DarkHover : Windows10AcrylicColors.LightHover;
    protected Color Pressed => IsDark ? Windows10AcrylicColors.DarkPressed : Windows10AcrylicColors.LightPressed;
    protected Color Selection => IsDark ? Windows10AcrylicColors.DarkSelection : Windows10AcrylicColors.LightSelection;

    public override Color GetBackColor1(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
            return SharedStaticVariables.EMPTY_COLOR;
        if (state is PaletteState.Tracking or PaletteState.CheckedTracking) return Hover;
        if (state is PaletteState.Pressed or PaletteState.CheckedPressed) return Pressed;

        return style switch
        {
            PaletteBackStyle.FormMain or PaletteBackStyle.HeaderForm => Background,
            PaletteBackStyle.Control or PaletteBackStyle.ControlClient or PaletteBackStyle.ControlAlternate
                or PaletteBackStyle.PanelClient or PaletteBackStyle.PanelAlternate => SurfaceSecondary,
            PaletteBackStyle.InputControlStandalone or PaletteBackStyle.InputControlRibbon
                or PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonAlternate
                or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonListItem
                or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonCluster
                or PaletteBackStyle.ButtonForm or PaletteBackStyle.ButtonFormClose => Surface,
            PaletteBackStyle.ContextMenuOuter or PaletteBackStyle.ContextMenuInner => Surface,
            PaletteBackStyle.ContextMenuItemHighlight => Selection,
            _ => base.GetBackColor1(style, state)
        };
    }

    public override Color GetBackColor2(PaletteBackStyle style, PaletteState state) =>
        GetBackColor1(style, state);

    public override PaletteColorStyle GetBackColorStyle(PaletteBackStyle style, PaletteState state) =>
        CommonHelper.IsOverrideState(state) ? PaletteColorStyle.Inherit : PaletteColorStyle.Solid;

    public override Color GetBorderColor1(PaletteBorderStyle style, PaletteState state) =>
        CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride)
            ? SharedStaticVariables.EMPTY_COLOR
            : Border;

    public override Color GetBorderColor2(PaletteBorderStyle style, PaletteState state) =>
        GetBorderColor1(style, state);

    public override Color GetContentShortTextColor1(PaletteContentStyle style, PaletteState state) =>
        state == PaletteState.Disabled ? DisabledText : Text;

    public override Color GetContentLongTextColor1(PaletteContentStyle style, PaletteState state) =>
        state == PaletteState.Disabled ? DisabledText : Text;
}
