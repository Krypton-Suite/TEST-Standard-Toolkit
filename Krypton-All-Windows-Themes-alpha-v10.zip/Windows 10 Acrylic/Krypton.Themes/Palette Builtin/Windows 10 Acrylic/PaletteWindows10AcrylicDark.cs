namespace Krypton.Themes;

public class PaletteWindows10AcrylicDark : PaletteWindows10AcrylicBase
{
    protected override bool IsDark => true;
    public PaletteWindows10AcrylicDark() => ThemeName = nameof(PaletteWindows10AcrylicDark);
}
