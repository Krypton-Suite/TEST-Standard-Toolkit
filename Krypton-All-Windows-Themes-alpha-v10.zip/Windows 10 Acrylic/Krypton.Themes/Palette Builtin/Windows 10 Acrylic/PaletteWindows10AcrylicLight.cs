namespace Krypton.Themes;

public class PaletteWindows10AcrylicLight : PaletteWindows10AcrylicBase
{
    protected override bool IsDark => false;
    public PaletteWindows10AcrylicLight() => ThemeName = nameof(PaletteWindows10AcrylicLight);
}
