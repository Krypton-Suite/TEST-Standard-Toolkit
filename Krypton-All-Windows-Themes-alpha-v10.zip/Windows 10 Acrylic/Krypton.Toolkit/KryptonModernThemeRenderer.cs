using System.Drawing;

namespace Krypton.Toolkit
{
    internal static class KryptonModernThemeRenderer
    {
        public static void DrawButton(Graphics g, Rectangle bounds,
            Color fill, Color border, bool hot, bool pressed)
        {
            Color surface = pressed ? ControlPaint.Dark(fill, 0.08f)
                : hot ? ControlPaint.Light(fill, 0.08f) : fill;

            using var brush = new SolidBrush(surface);
            using var pen = new Pen(border);
            g.FillRectangle(brush, bounds);
            g.DrawRectangle(pen, bounds.X, bounds.Y,
                bounds.Width - 1, bounds.Height - 1);
        }

        public static void DrawSelection(Graphics g, Rectangle bounds, Color selection)
        {
            using var brush = new SolidBrush(selection);
            g.FillRectangle(brush, bounds);
        }
    }
}
