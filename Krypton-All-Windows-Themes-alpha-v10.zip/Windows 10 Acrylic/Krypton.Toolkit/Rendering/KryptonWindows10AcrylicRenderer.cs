namespace Krypton.Toolkit;

public sealed class KryptonWindows10AcrylicRenderer : KryptonProfessionalRenderer
{
    public KryptonWindows10AcrylicRenderer([DisallowNull] KryptonColorTable kct) : base(kct) { }

    protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
    {
        if (e.Item.Selected)
        {
            var colour = KCT.Palette.GetBackColor1(
                PaletteBackStyle.ContextMenuItemHighlight, PaletteState.Tracking);
            if (colour != Color.Empty)
            {
                using var brush = new SolidBrush(colour);
                e.Graphics.FillRectangle(brush, new Rectangle(Point.Empty, e.Item.Size));
                return;
            }
        }
        base.OnRenderMenuItemBackground(e);
    }

    protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
    {
        var colour = KCT.Palette.GetBackColor1(PaletteBackStyle.Control, PaletteState.Normal);
        using var brush = new SolidBrush(colour);
        e.Graphics.FillRectangle(brush, new Rectangle(Point.Empty, e.ToolStrip.Size));
    }
}
