#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>Semantic control primitives for the modern Acrylic/Mica themes.</summary>
public static class WindowsModernControlPainter
{
    public static void DrawControl(Graphics g, Rectangle r, Color fill, Color border, bool hot = false, bool pressed = false)
    {
        if (g == null || r.Width <= 0 || r.Height <= 0) return;

        g.SmoothingMode = SmoothingMode.None;
        using var brush = new SolidBrush(pressed ? ControlPaint.Dark(fill) : fill);
        using var pen = new Pen(hot ? ControlPaint.Dark(border) : border);

        g.FillRectangle(brush, r);
        if (r.Width > 1 && r.Height > 1)
        {
            g.DrawRectangle(pen, r.X, r.Y, r.Width - 1, r.Height - 1);
        }
    }

    public static void DrawCheck(Graphics g, Rectangle r, bool selected,
        Color fill, Color border, Color accent)
    {
        if (g == null || r.Width <= 0 || r.Height <= 0) return;

        DrawControl(g, r, fill, border);
        if (!selected) return;

        using var pen = new Pen(accent, Math.Max(1f, Math.Min(r.Width, r.Height) / 7f))
        {
            StartCap = LineCap.Round,
            EndCap = LineCap.Round,
            LineJoin = LineJoin.Round
        };

        int left = r.X + r.Width / 5;
        int middle = r.X + r.Width * 2 / 5;
        int right = r.X + r.Width * 4 / 5;
        int top = r.Y + r.Height / 5;
        int centre = r.Y + r.Height / 2;
        int bottom = r.Y + r.Height * 4 / 5;

        g.DrawLines(pen,
        [
            new Point(left, centre),
            new Point(middle, bottom),
            new Point(right, top)
        ]);
    }
}
