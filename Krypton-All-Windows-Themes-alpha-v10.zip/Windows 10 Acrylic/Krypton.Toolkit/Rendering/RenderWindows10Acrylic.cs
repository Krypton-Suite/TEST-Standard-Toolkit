namespace Krypton.Toolkit;

public sealed class RenderWindows10Acrylic : RenderOffice2010
{
    public override ToolStripRenderer RenderToolStrip([DisallowNull] PaletteBase? colorPalette)
    {
        if (colorPalette == null) ThrowHelper.ThrowArgumentNullException(nameof(colorPalette));
        return new KryptonWindows10AcrylicRenderer(colorPalette.ColorTable);
    }

    public override GraphicsPath GetBackPath(RenderContext context, Rectangle rect,
        IPaletteBorder palette, VisualOrientation orientation, PaletteState state)
    {
        var path = new GraphicsPath();
        if (rect.Width > 0 && rect.Height > 0) path.AddRectangle(rect);
        return path;
    }
}
