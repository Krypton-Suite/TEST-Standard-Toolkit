namespace Krypton.Toolkit;

public static class Windows10Acrylic
{
    private const int DWMWA_USE_HOSTBACKDROPBRUSH = 17;

    public static bool Apply(Form form, Windows10AcrylicKind kind = Windows10AcrylicKind.Base)
    {
        if (form == null) throw new ArgumentNullException(nameof(form));
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) return false;

        form.HandleCreated -= FormHandleCreated;
        form.HandleCreated += FormHandleCreated;
        if (form.IsHandleCreated) ApplyToHandle(form.Handle, kind);
        return true;

        void FormHandleCreated(object? sender, EventArgs e)
        {
            if (sender is Form created) ApplyToHandle(created.Handle, kind);
        }
    }

    public static bool Remove(Form form)
    {
        if (form == null) throw new ArgumentNullException(nameof(form));
        return form.IsHandleCreated && RuntimeInformation.IsOSPlatform(OSPlatform.Windows);
    }

    private static void ApplyToHandle(IntPtr hwnd, Windows10AcrylicKind kind)
    {
        int enabled = 1;
        _ = DwmSetWindowAttribute(hwnd, DWMWA_USE_HOSTBACKDROPBRUSH,
            ref enabled, sizeof(int));
    }

    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(
        IntPtr hwnd, int attribute, ref int value, int size);
}

public enum Windows10AcrylicKind
{
    Base,
    Thin
}
