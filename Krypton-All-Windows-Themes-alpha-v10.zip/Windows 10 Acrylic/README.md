# Windows 10 Acrylic for Krypton Standard Toolkit

Dedicated Fluent/Acrylic palette and renderer sources.

Acrylic is a compositor material rather than a static colour. Microsoft
describes it as translucency + blur + noise + exclusion blending + tint.
Background Acrylic is primarily intended for transient surfaces; in-app
Acrylic is intended for supporting surfaces.

This package supplies:
- RenderWindows10Acrylic
- KryptonWindows10AcrylicRenderer
- Windows10Acrylic
- Light and Dark Acrylic palettes
- Solid fallback colours

The Win32 helper enables the host-backdrop path (`DWMWA_USE_HOSTBACKDROPBRUSH`).
Actual live Desktop Acrylic on Windows 10 normally requires the Windows App
SDK Composition/DesktopAcrylicController path. This package deliberately
does not add a Windows App SDK dependency.

Central PaletteMode and KryptonExtendedThemeProvider registration are omitted
so the files can be reviewed against the current alpha branch before merging.
