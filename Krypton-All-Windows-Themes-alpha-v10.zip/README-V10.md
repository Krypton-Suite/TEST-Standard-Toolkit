# Krypton Windows Themes alpha v10

This is the next source-preparation bundle following v9.

The key architectural point is that Windows theme artwork belongs in `Krypton.Resources` as `.resx` resources. The toolkit/theme renderers should consume those typed resources rather than maintaining duplicate loose bitmap resources.

v10 also fixes two known source-level problems from the earlier alpha material:

- `WindowsModernControlPainter` no longer references the nonexistent `WindowsThemeControlPainter`.
- Windows 10 Acrylic no longer depends on `OperatingSystem.IsWindows*`, avoiding the legacy-target-framework compiler failure.

See `BUILD-VALIDATION-REPORT.md` before merging into the actual Standard Toolkit checkout.
