# Resource naming convention

All extracted bitmap resources in the collection use normal C#/.NET-style
PascalCase names rather than the uppercase identifiers used internally by the
original XP `.msstyles` resources.

Examples:

- `BUTTON_BMP` -> `Button.bmp`
- `CHECKBOX25_BMP` -> `Checkbox25.bmp`
- `RADIOBUTTON25_BMP` -> `RadioButton25.bmp`
- `PROGRESSTRACK_BMP` -> `ProgressTrack.bmp`
- `SCROLLTHUMBVERTICAL_BMP` -> `ScrollThumbVertical.bmp`

The binary contents of the resources are unchanged; only the filenames and
corresponding source references have been normalised.
