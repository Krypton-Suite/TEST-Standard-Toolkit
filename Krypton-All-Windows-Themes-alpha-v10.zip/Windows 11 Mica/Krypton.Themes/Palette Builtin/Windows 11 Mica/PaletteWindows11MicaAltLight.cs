#region BSD License
namespace Krypton.Themes;

/// <summary>Windows 11 Mica Alt light palette.</summary>
public sealed class PaletteWindows11MicaAltLight : PaletteWindows11MicaLight
{
    public PaletteWindows11MicaAltLight()
    {
        ThemeName = nameof(PaletteWindows11MicaAltLight);
    }
}
