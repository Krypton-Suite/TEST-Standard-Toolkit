#region BSD License
namespace Krypton.Themes;

/// <summary>Windows 11 Mica Alt dark palette.</summary>
public sealed class PaletteWindows11MicaAltDark : PaletteWindows11MicaDark
{
    public PaletteWindows11MicaAltDark()
    {
        ThemeName = nameof(PaletteWindows11MicaAltDark);
    }
}
