#region BSD License
namespace Krypton.Themes;

/// <summary>Windows 11 Mica dark palette.</summary>
public class PaletteWindows11MicaDark : PaletteWindows11MicaBase
{
    protected override bool IsDark => true;

    public PaletteWindows11MicaDark()
    {
        ThemeName = nameof(PaletteWindows11MicaDark);
    }
}
