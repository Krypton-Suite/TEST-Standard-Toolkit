#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Windows 11 Mica palette base.
 */
#endregion

namespace Krypton.Themes;

using Krypton.Toolkit;

/// <summary>
/// Shared base for the Windows 11 Mica light and dark palettes.
/// </summary>
public abstract class PaletteWindows11MicaBase : PaletteProfessionalSystem
{
    /// <summary>Gets whether this palette represents Windows 11 dark mode.</summary>
    protected abstract bool IsDark { get; }

    /// <inheritdoc />
    public override IRenderer GetRenderer() => new RenderWindows11Mica();

    protected Color Background => IsDark
        ? Windows11MicaColors.DarkBackground
        : Windows11MicaColors.LightBackground;

    protected Color Surface => IsDark
        ? Windows11MicaColors.DarkSurface
        : Windows11MicaColors.LightSurface;

    protected Color SurfaceSecondary => IsDark
        ? Windows11MicaColors.DarkSurfaceSecondary
        : Windows11MicaColors.LightSurfaceSecondary;

    protected Color Border => IsDark
        ? Windows11MicaColors.DarkBorder
        : Windows11MicaColors.LightBorder;

    protected Color Text => IsDark
        ? Windows11MicaColors.DarkText
        : Windows11MicaColors.LightText;

    protected Color TextSecondary => IsDark
        ? Windows11MicaColors.DarkTextSecondary
        : Windows11MicaColors.LightTextSecondary;

    protected Color DisabledText => IsDark
        ? Windows11MicaColors.DarkTextDisabled
        : Windows11MicaColors.LightTextDisabled;

    protected Color Hover => IsDark
        ? Windows11MicaColors.DarkHover
        : Windows11MicaColors.LightHover;

    protected Color Pressed => IsDark
        ? Windows11MicaColors.DarkPressed
        : Windows11MicaColors.LightPressed;

    protected Color Selection => IsDark
        ? Windows11MicaColors.DarkSelection
        : Windows11MicaColors.LightSelection;

    /// <inheritdoc />
    public override Color GetBackColor1(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        if (state is PaletteState.Tracking or PaletteState.CheckedTracking)
        {
            return style switch
            {
                PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonAlternate
                    or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonListItem
                    or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonCluster
                    or PaletteBackStyle.ButtonNavigatorStack or PaletteBackStyle.ButtonNavigatorOverflow
                    or PaletteBackStyle.ButtonNavigatorMini
                    or PaletteBackStyle.ContextMenuItemHighlight
                    => Hover,
                _ => base.GetBackColor1(style, state)
            };
        }

        if (state is PaletteState.Pressed or PaletteState.CheckedPressed)
        {
            return Pressed;
        }

        return style switch
        {
            PaletteBackStyle.FormMain or PaletteBackStyle.FormCustom1 or PaletteBackStyle.FormCustom2
                or PaletteBackStyle.FormCustom3 or PaletteBackStyle.HeaderForm
                => Background,

            PaletteBackStyle.Control or PaletteBackStyle.ControlClient or PaletteBackStyle.ControlAlternate
                or PaletteBackStyle.ControlCustom1 or PaletteBackStyle.ControlCustom2 or PaletteBackStyle.ControlCustom3
                or PaletteBackStyle.PanelClient or PaletteBackStyle.PanelAlternate
                => SurfaceSecondary,

            PaletteBackStyle.InputControlStandalone or PaletteBackStyle.InputControlRibbon
                or PaletteBackStyle.InputControlCustom1 or PaletteBackStyle.InputControlCustom2
                or PaletteBackStyle.InputControlCustom3
                => Surface,

            PaletteBackStyle.ButtonStandalone or PaletteBackStyle.ButtonAlternate
                or PaletteBackStyle.ButtonLowProfile or PaletteBackStyle.ButtonListItem
                or PaletteBackStyle.ButtonCommand or PaletteBackStyle.ButtonCluster
                or PaletteBackStyle.ButtonNavigatorStack or PaletteBackStyle.ButtonNavigatorOverflow
                or PaletteBackStyle.ButtonNavigatorMini or PaletteBackStyle.ButtonForm
                or PaletteBackStyle.ButtonFormClose
                => Surface,

            PaletteBackStyle.ContextMenuOuter or PaletteBackStyle.ContextMenuInner
                => Surface,

            PaletteBackStyle.ContextMenuItemHighlight
                => Selection,

            PaletteBackStyle.GridDataCellList or PaletteBackStyle.GridDataCellSheet
                or PaletteBackStyle.GridDataCellCustom1 or PaletteBackStyle.GridDataCellCustom2
                or PaletteBackStyle.GridDataCellCustom3
                => Surface,

            PaletteBackStyle.GridHeaderColumnList or PaletteBackStyle.GridHeaderColumnSheet
                or PaletteBackStyle.GridHeaderColumnCustom1 or PaletteBackStyle.GridHeaderColumnCustom2
                or PaletteBackStyle.GridHeaderColumnCustom3
                or PaletteBackStyle.GridHeaderRowList or PaletteBackStyle.GridHeaderRowSheet
                or PaletteBackStyle.GridHeaderRowCustom1 or PaletteBackStyle.GridHeaderRowCustom2
                or PaletteBackStyle.GridHeaderRowCustom3
                => SurfaceSecondary,

            PaletteBackStyle.ControlToolTip => Surface,
            _ => base.GetBackColor1(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetBackColor2(PaletteBackStyle style, PaletteState state) =>
        GetBackColor1(style, state);

    /// <inheritdoc />
    public override PaletteColorStyle GetBackColorStyle(PaletteBackStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideState(state))
        {
            return PaletteColorStyle.Inherit;
        }

        return PaletteColorStyle.Solid;
    }

    /// <inheritdoc />
    public override Color GetBorderColor1(PaletteBorderStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideStateExclude(state, PaletteState.NormalDefaultOverride))
        {
            return SharedStaticVariables.EMPTY_COLOR;
        }

        return style switch
        {
            PaletteBorderStyle.ButtonStandalone or PaletteBorderStyle.ButtonAlternate
                or PaletteBorderStyle.ButtonLowProfile or PaletteBorderStyle.ButtonListItem
                or PaletteBorderStyle.ButtonCommand or PaletteBorderStyle.ButtonCluster
                or PaletteBorderStyle.ButtonNavigatorStack or PaletteBorderStyle.ButtonNavigatorOverflow
                or PaletteBorderStyle.ButtonNavigatorMini or PaletteBorderStyle.ButtonForm
                or PaletteBorderStyle.ButtonFormClose
                or PaletteBorderStyle.ButtonCustom1 or PaletteBorderStyle.ButtonCustom2
                or PaletteBorderStyle.ButtonCustom3
                or PaletteBorderStyle.InputControlStandalone or PaletteBorderStyle.InputControlRibbon
                or PaletteBorderStyle.InputControlCustom1 or PaletteBorderStyle.InputControlCustom2
                or PaletteBorderStyle.InputControlCustom3
                or PaletteBorderStyle.ControlClient or PaletteBorderStyle.ControlAlternate
                or PaletteBorderStyle.ControlGroupBox
                or PaletteBorderStyle.ContextMenuOuter or PaletteBorderStyle.ContextMenuInner
                or PaletteBorderStyle.FormMain or PaletteBorderStyle.FormCustom1
                or PaletteBorderStyle.FormCustom2 or PaletteBorderStyle.FormCustom3
                or PaletteBorderStyle.HeaderForm
                => state == PaletteState.Disabled ? DisabledText : Border,
            _ => base.GetBorderColor1(style, state)
        };
    }

    /// <inheritdoc />
    public override Color GetBorderColor2(PaletteBorderStyle style, PaletteState state) =>
        GetBorderColor1(style, state);

    /// <inheritdoc />
    public override Color GetContentShortTextColor1(PaletteContentStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideState(state))
        {
            return base.GetContentShortTextColor1(style, state);
        }

        if (state == PaletteState.Disabled)
        {
            return DisabledText;
        }

        return Text;
    }

    /// <inheritdoc />
    public override Color GetContentLongTextColor1(PaletteContentStyle style, PaletteState state)
    {
        if (CommonHelper.IsOverrideState(state))
        {
            return base.GetContentLongTextColor1(style, state);
        }

        if (state == PaletteState.Disabled)
        {
            return DisabledText;
        }

        return Text;
    }
}
