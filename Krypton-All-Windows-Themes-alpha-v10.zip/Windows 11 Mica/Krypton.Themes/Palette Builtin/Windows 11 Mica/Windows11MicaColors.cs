#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Windows 11 Fluent/Mica semantic colour definitions.
 */
#endregion

namespace Krypton.Themes;

internal static class Windows11MicaColors
{
    // These are fallback/theme colours. The Mica material itself is supplied by DWM.
    internal static readonly Color LightBackground = Color.FromArgb(243, 243, 243);
    internal static readonly Color LightSurface = Color.FromArgb(255, 255, 255);
    internal static readonly Color LightSurfaceSecondary = Color.FromArgb(249, 249, 249);
    internal static readonly Color LightBorder = Color.FromArgb(225, 225, 225);
    internal static readonly Color LightBorderStrong = Color.FromArgb(210, 210, 210);
    internal static readonly Color LightText = Color.FromArgb(32, 32, 32);
    internal static readonly Color LightTextSecondary = Color.FromArgb(95, 95, 95);
    internal static readonly Color LightTextDisabled = Color.FromArgb(160, 160, 160);
    internal static readonly Color LightHover = Color.FromArgb(229, 229, 229);
    internal static readonly Color LightPressed = Color.FromArgb(215, 215, 215);
    internal static readonly Color LightSelection = Color.FromArgb(204, 228, 255);

    internal static readonly Color DarkBackground = Color.FromArgb(32, 32, 32);
    internal static readonly Color DarkSurface = Color.FromArgb(43, 43, 43);
    internal static readonly Color DarkSurfaceSecondary = Color.FromArgb(38, 38, 38);
    internal static readonly Color DarkBorder = Color.FromArgb(70, 70, 70);
    internal static readonly Color DarkBorderStrong = Color.FromArgb(85, 85, 85);
    internal static readonly Color DarkText = Color.FromArgb(243, 243, 243);
    internal static readonly Color DarkTextSecondary = Color.FromArgb(190, 190, 190);
    internal static readonly Color DarkTextDisabled = Color.FromArgb(110, 110, 110);
    internal static readonly Color DarkHover = Color.FromArgb(55, 55, 55);
    internal static readonly Color DarkPressed = Color.FromArgb(65, 65, 65);
    internal static readonly Color DarkSelection = Color.FromArgb(51, 103, 153);

    internal static readonly Color WindowsAccent = Color.FromArgb(0, 120, 212);
    internal static readonly Color WindowsAccentHover = Color.FromArgb(0, 99, 177);
    internal static readonly Color WindowsAccentPressed = Color.FromArgb(0, 83, 150);
}
