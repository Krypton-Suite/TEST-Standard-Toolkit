#region BSD License
namespace Krypton.Themes;

/// <summary>Windows 11 Mica light palette.</summary>
public class PaletteWindows11MicaLight : PaletteWindows11MicaBase
{
    protected override bool IsDark => false;

    public PaletteWindows11MicaLight()
    {
        ThemeName = nameof(PaletteWindows11MicaLight);
    }
}
