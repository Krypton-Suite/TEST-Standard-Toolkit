#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>Semantic control primitives for the modern Acrylic/Mica themes.
/// The DWM material remains responsible for the actual backdrop; these primitives
/// provide the corresponding Krypton control surfaces.
/// </summary>
public static class WindowsModernControlPainter
{
    public static void DrawControl(Graphics g, Rectangle r, Color fill, Color border, bool hot=false, bool pressed=false)
    {
        if(r.Width<=0||r.Height<=0)return; g.SmoothingMode=SmoothingMode.None;
        using var b=new SolidBrush(pressed?ControlPaint.Dark(fill):fill); using var p=new Pen(hot?ControlPaint.Dark(border):border);
        g.FillRectangle(b,r); if(r.Width>1&&r.Height>1)g.DrawRectangle(p,r.X,r.Y,r.Width-1,r.Height-1);
    }
    public static void DrawCheck(Graphics g, Rectangle r, bool selected, Color fill, Color border, Color accent)
        => WindowsThemeControlPainter.DrawCheckBox(g,r,selected,false,false,fill,border,accent);
}
