#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Windows 11 Mica ToolStrip/Menu renderer.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// Fluent-style ToolStrip renderer used by the Windows 11 Mica themes.
/// </summary>
public sealed class KryptonWindows11MicaRenderer : KryptonProfessionalRenderer
{
    public KryptonWindows11MicaRenderer([DisallowNull] KryptonColorTable kct)
        : base(kct)
    {
    }

    protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
    {
        if (e.Item is ToolStripMenuItem && e.Item.Selected)
        {
            var g = e.Graphics;
            var oldSmoothing = g.SmoothingMode;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;

            try
            {
                Color highlight = KCT.Palette.GetBackColor1(
                    PaletteBackStyle.ContextMenuItemHighlight,
                    PaletteState.Tracking);

                if (highlight == Color.Empty)
                {
                    highlight = KCT.Palette.GetBackColor1(
                        PaletteBackStyle.ButtonListItem,
                        PaletteState.Tracking);
                }

                using var brush = new SolidBrush(highlight);
                g.FillRectangle(brush, new Rectangle(Point.Empty, e.Item.Size));
            }
            finally
            {
                g.SmoothingMode = oldSmoothing;
            }

            return;
        }

        base.OnRenderMenuItemBackground(e);
    }

    protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
    {
        Color fill = KCT.Palette.GetBackColor1(
            PaletteBackStyle.Control,
            PaletteState.Normal);

        using var brush = new SolidBrush(fill);
        e.Graphics.FillRectangle(brush, new Rectangle(Point.Empty, e.ToolStrip.Size));
    }
}
