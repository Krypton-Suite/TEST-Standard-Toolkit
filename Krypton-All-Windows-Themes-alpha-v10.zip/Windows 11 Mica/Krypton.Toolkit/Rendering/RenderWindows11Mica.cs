#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Windows 11 Mica renderer for Krypton Standard Toolkit.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// Windows 11 Fluent/Mica renderer. Keeps Krypton's normal rendering pipeline,
/// while applying the flatter, square Fluent treatment appropriate to Mica
/// palettes and providing a dedicated ToolStrip renderer.
/// </summary>
public sealed class RenderWindows11Mica : RenderOffice2010
{
    /// <inheritdoc />
    public override ToolStripRenderer RenderToolStrip([DisallowNull] PaletteBase? colorPalette)
    {
        if (colorPalette == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(colorPalette));
        }

        return new KryptonWindows11MicaRenderer(colorPalette.ColorTable);
    }

    /// <inheritdoc />
    public override GraphicsPath GetBackPath(
        [DisallowNull] RenderContext context,
        Rectangle rect,
        [DisallowNull] IPaletteBorder palette,
        VisualOrientation orientation,
        PaletteState state)
    {
        if (rect.Width <= 0 || rect.Height <= 0)
        {
            return base.GetBackPath(context, rect, palette, orientation, state);
        }

        // Mica/Fluent controls use restrained, generally square geometry in
        // the Krypton WinForms renderer. Rounded window chrome is supplied by DWM.
        var path = new GraphicsPath();
        path.AddRectangle(rect);
        return path;
    }

    /// <inheritdoc />
    public override void DrawBorder(
        RenderContext context,
        Rectangle rect,
        IPaletteBorder palette,
        VisualOrientation orientation,
        PaletteState state)
    {
        if (palette == null)
        {
            ThrowHelper.ThrowArgumentNullException(nameof(palette));
        }

        if (rect.Width <= 0 || rect.Height <= 0 ||
            palette.GetBorderWidth(state) <= 0 ||
            palette.GetBorderDraw(state) != InheritBool.True ||
            !CommonHelper.HasABorder(palette.GetBorderDrawBorders(state)))
        {
            return;
        }

        // Mica uses subtle 1px borders rather than the heavier Office bevel.
        base.DrawBorder(context, rect, palette, orientation, state);
    }
}
