#region BSD License
/*
 * New BSD 3-Clause License (https://github.com/Krypton-Suite/Standard-Toolkit/blob/master/LICENSE)
 * Windows 11 Mica Win32/DWM integration.
 */
#endregion

namespace Krypton.Toolkit;

/// <summary>
/// Applies the Windows 11 DWM Mica backdrop to a WinForms window.
/// </summary>
/// <remarks>
/// Mica is an opaque, wallpaper-tinted system material. The compositor owns
/// the backdrop; this helper therefore complements the Krypton renderer rather
/// than attempting to paint Mica pixels itself.
/// </remarks>
public static class Windows11Mica
{
    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_CAPTION_COLOR = 35;
    private const int DWMWA_TEXT_COLOR = 36;
    private const int DWMWA_SYSTEMBACKDROP_TYPE = 38;

    private const int DWMSBT_MAINWINDOW = 2; // Mica
    private const int DWMSBT_TABBEDWINDOW = 4; // Mica Alt

    /// <summary>
    /// Applies Windows 11 Mica to <paramref name="form"/>.
    /// </summary>
    public static bool Apply(Form form, Windows11MicaKind kind = Windows11MicaKind.Base,
        bool darkMode = false)
    {
        if (form == null)
        {
            throw new ArgumentNullException(nameof(form));
        }

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        if (!OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000))
        {
            return false;
        }

        form.HandleCreated -= FormHandleCreated;
        form.HandleCreated += FormHandleCreated;

        if (form.IsHandleCreated)
        {
            ApplyToHandle(form.Handle, kind, darkMode);
        }

        return true;

        void FormHandleCreated(object? sender, EventArgs e)
        {
            if (sender is Form created)
            {
                ApplyToHandle(created.Handle, kind, darkMode);
            }
        }
    }

    /// <summary>Removes the DWM Mica backdrop from a window.</summary>
    public static bool Remove(Form form)
    {
        if (form == null)
        {
            throw new ArgumentNullException(nameof(form));
        }

        if (!form.IsHandleCreated || !OperatingSystem.IsWindows())
        {
            return false;
        }

        int value = 1; // DWMSBT_NONE
        return DwmSetWindowAttribute(
            form.Handle,
            DWMWA_SYSTEMBACKDROP_TYPE,
            ref value,
            sizeof(int)) == 0;
    }

    private static void ApplyToHandle(IntPtr hwnd, Windows11MicaKind kind, bool darkMode)
    {
        int backdrop = kind == Windows11MicaKind.BaseAlt
            ? DWMSBT_TABBEDWINDOW
            : DWMSBT_MAINWINDOW;

        _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_SYSTEMBACKDROP_TYPE,
            ref backdrop,
            sizeof(int));

        int dark = darkMode ? 1 : 0;
        _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_USE_IMMERSIVE_DARK_MODE,
            ref dark,
            sizeof(int));
    }

    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(
        IntPtr hwnd,
        int dwAttribute,
        ref int pvAttribute,
        int cbAttribute);
}

/// <summary>Windows 11 Mica material variant.</summary>
public enum Windows11MicaKind
{
    /// <summary>Standard Mica, intended for primary application surfaces.</summary>
    Base,

    /// <summary>Mica Alt, with a stronger tint, useful for tabbed/secondary chrome.</summary>
    BaseAlt
}
