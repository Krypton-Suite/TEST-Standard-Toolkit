# Windows 11 Mica for Krypton Standard Toolkit

This package provides the source for a Windows 11 Fluent/Mica theme family.

## Included

### Krypton.Toolkit
- `RenderWindows11Mica`
- `KryptonWindows11MicaRenderer`
- `Windows11Mica`

### Krypton.Themes
- `PaletteWindows11MicaBase`
- `PaletteWindows11MicaLight`
- `PaletteWindows11MicaDark`
- `PaletteWindows11MicaAltLight`
- `PaletteWindows11MicaAltDark`
- `Windows11MicaColors`

## Important architecture note

Mica is not a colour/blur effect that should be painted by a WinForms renderer.
Windows 11 supplies Mica through the Desktop Window Manager (DWM). The
`Windows11Mica` helper therefore applies `DWMWA_SYSTEMBACKDROP_TYPE` to the
Form, while the Krypton palette/renderer handles the controls drawn inside it.

Use:

```csharp
Windows11Mica.Apply(this, Windows11MicaKind.Base, darkMode: false);
```

or:

```csharp
Windows11Mica.Apply(this, Windows11MicaKind.BaseAlt, darkMode: true);
```

Call it after the form handle exists (the helper also hooks `HandleCreated`).

## Windows compatibility

The helper is a no-op on Windows versions before Windows 11 (build 22000).
The application still has a normal Krypton solid-colour fallback.

Mica is an opaque, wallpaper-tinted material intended for long-lived surfaces.
Mica Alt is the stronger-tinted variant intended for secondary/tabbed chrome.

## Repository integration

The current Krypton alpha branch centralises built-in theme registration in
`KryptonExtendedThemeProvider`. To expose these as selectable `PaletteMode`
values, add the four `PaletteMode` values and the corresponding
`KryptonThemeFamilies`/`KryptonThemeChromeKind` entries, then register them in
that provider.

This ZIP intentionally does not modify central enums/provider files so it can
be reviewed and merged cleanly.

## Design intent

The palette deliberately avoids pretending that Mica itself is a static RGB
palette. The fallback colours are semantic Fluent colours; the actual Mica
wallpaper tint and active/inactive treatment are supplied by Windows DWM.
